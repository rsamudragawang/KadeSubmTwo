package com.ganargatul.kadesubmtwo.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log.d
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ganargatul.kadesubmtwo.R
import com.ganargatul.kadesubmtwo.adapter.NextEventAdapter
import com.ganargatul.kadesubmtwo.connection.RetroConfig
import com.ganargatul.kadesubmtwo.model.NextEventsItems
import com.ganargatul.kadesubmtwo.model.SearchEventResponse
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Response

class SearchActivity : AppCompatActivity() {
    lateinit var progressbar: ProgressBar
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: NextEventAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        var stringextra = intent.getStringExtra("query")
        progressbar = findViewById(R.id.progress_search)
        progressbar.visibility = View.VISIBLE
        recyclerView= findViewById(R.id.rv_search)
        recyclerView.layoutManager= LinearLayoutManager(baseContext)
        RetroConfig().services.searchEvents(stringextra).enqueue(object : retrofit2.Callback<SearchEventResponse>{
            override fun onFailure(call: Call<SearchEventResponse>, t: Throwable) {
                d("failure",t.message)
            }

            override fun onResponse(
                call: Call<SearchEventResponse>,
                response: Response<SearchEventResponse>
            ) {
                progressbar.visibility =View.GONE
                if (response.code() == 200){
                    if (response.body()?.event?.size!! > 0){
                        response.body()?.event.let {
                            it?.let { it1 -> showItems(it1) }
                        }
                    }else{
                        Toast.makeText(baseContext, "Not Found", Toast.LENGTH_SHORT).show()
                    }

                }
            }

        })
    }

    private fun showItems(it1: List<NextEventsItems>) {
        adapter= NextEventAdapter(baseContext,it1){
            var nowItems = NextEventsItems(it.idEvent,it.strEvent,it.dateEvent,it.strTime,it.idHomeTeam,it.idAwayTeam)
            startActivity<DetailNextEvent>("Data" to nowItems)
        }

        recyclerView.adapter = adapter
    }
}
